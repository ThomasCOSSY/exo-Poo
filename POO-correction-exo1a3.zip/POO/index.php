<?php
require 'Models/Character.php';

$character = new Character();
var_dump($character);